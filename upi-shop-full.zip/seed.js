const mongoose = require('mongoose');
const Product = require('./models/Product');

mongoose.connect('mongodb://localhost:27017/upishop');

Product.insertMany([
  { name: 'T-shirt', price: 299 },
  { name: 'Earphones', price: 499 },
  { name: 'Shoes', price: 999 },
]).then(() => {
  console.log("Products seeded");
  process.exit();
});