const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const path = require('path');

const User = require('./models/User');
const Product = require('./models/Product');
const Order = require('./models/Order');

const app = express();
const secret = 'your_secret_key';

app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

mongoose.connect('mongodb://localhost:27017/upishop', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

function authMiddleware(req, res, next) {
  const token = req.headers['authorization'];
  try {
    const decoded = jwt.verify(token, secret);
    req.user = decoded;
    next();
  } catch {
    res.status(403).json({ message: 'Invalid token' });
  }
}

app.post('/api/signup', async (req, res) => {
  const { email, password } = req.body;
  const user = await User.create({ email, password });
  res.json({ message: 'Signup success' });
});

app.post('/api/login', async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email, password });
  if (!user) return res.status(401).json({ message: 'Invalid credentials' });
  const token = jwt.sign({ id: user._id, isAdmin: user.isAdmin }, secret);
  res.json({ token });
});

app.get('/api/products', async (req, res) => {
  const products = await Product.find();
  res.json(products);
});

app.post('/api/cart', authMiddleware, async (req, res) => {
  const { productId } = req.body;
  const product = await Product.findById(productId);
  const order = new Order({
    userId: req.user.id,
    productIds: [productId],
    total: product.price,
  });
  await order.save();
  res.sendStatus(200);
});

app.get('/api/orders', authMiddleware, async (req, res) => {
  const orders = await Order.find({ userId: req.user.id });
  res.json(orders);
});

app.get('/api/admin/orders', authMiddleware, async (req, res) => {
  if (!req.user.isAdmin) return res.status(403).json({ message: 'Not admin' });
  const orders = await Order.find();
  res.json(orders);
});

app.get('/api/upi/:amount', (req, res) => {
  const upi = `upi://pay?pa=yourupi@okaxis&pn=UPI Shop&am=${req.params.amount}&cu=INR`;
  res.redirect(`https://chart.googleapis.com/chart?chs=250x250&cht=qr&chl=${encodeURIComponent(upi)}`);
});

app.listen(3000, () => {
  console.log('Server running on http://localhost:3000');
});